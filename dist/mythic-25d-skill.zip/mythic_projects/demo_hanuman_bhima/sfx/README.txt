Drop real SFX here named like the cue (e.g. horse_neigh.wav) to replace synthetic ones.

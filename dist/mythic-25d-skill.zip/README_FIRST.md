# Mythic 2.5D — painted puppet-theatre film skill for Claude Code

हिंदी: इस zip में पूरी Claude Code skill है — 602 पात्र, 117 पशु-पक्षी, 110 दृश्य, reference जैसा कैमरा,
ज़िंदा background, हिंदी आवाज़ + word-timed subtitles, संगीत, SFX, mix, grading, review.
इंस्टॉल: `mythic-25d/INSTALL.md` पढ़ें। Claude को कैसे बोलें: `mythic-25d/STARTER_PROMPT.md`।

English: the complete Claude Code skill. Install: `mythic-25d/INSTALL.md`. Prompts: `mythic-25d/STARTER_PROMPT.md`.

Contents
- `mythic-25d/`            → copy to `~/.claude/skills/mythic-25d/` (or `<project>/.claude/skills/mythic-25d/`)
- `mythic_projects/demo_hanuman_bhima/storyboard.yaml` → a full 7-shot demo to render
